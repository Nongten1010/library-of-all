import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-hero',
  standalone: true,
  imports: [],
  templateUrl: './admin-hero.component.html',
  styleUrl: './admin-hero.component.css'
})
export class AdminHeroComponent {

}
