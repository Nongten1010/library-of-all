import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-interlibrary-loan',
  standalone: true,
  imports: [],
  templateUrl: './admin-interlibrary-loan.component.html',
  styleUrl: './admin-interlibrary-loan.component.css'
})
export class AdminInterlibraryLoanComponent {

}
