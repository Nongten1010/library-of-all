
export const environment = {
  production: false,
  apiEndpoints: {
    addIllRequest: '/api/ill/Add_data_ill.php',
    addBuybookRequest: '/api/ill/Add_data_buybook.php'
    
  },
   apiUrl: 'http://localhost:8888/library-api'
};
