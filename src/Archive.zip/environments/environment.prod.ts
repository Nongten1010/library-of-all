export const environment = {
    production: true,
    apiEndpoints: {
      addIllRequest: 'https://api.myproductionserver.com/Add_data_ill.php'
    },
     apiUrl: 'https://yourdomain.com/library-api'
  };
  